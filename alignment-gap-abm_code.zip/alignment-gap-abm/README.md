# Identity-Based Alignment Gap in Design Education — Hybrid ABM/SD Model

Code, data, and documentation for:

> Guo, L., "Narrowing the Identity-Based Alignment Gap in Design Education: A Hybrid Agent-Based and
> System Dynamics Study," submitted to *ASME Journal of Mechanical Design* (resubmission of MD-26-1447).

Everything in the paper (every table, figure, and number) is produced by `run_all.py` from the code in
this repository. No classroom data are used. All inputs are simulated, and the parameter sources are listed in
Table 4 of the paper and in `alignment_abm/model.py`.

Repository: `https://github.com/<ACCOUNT>/alignment-gap-abm` (archived on Zenodo, DOI: `<to be minted at acceptance>`)

---

## 1. Quick start

```bash
python -m pip install -r requirements.txt
python -m pytest -q          # 16 unit/regression tests (about 2 s)
python run_all.py --quick    # smoke run (about 1 min)
python run_all.py            # full run used in the paper (about 4-5 min on 2 CPU cores)
```

Outputs:

| Folder | Content |
|---|---|
| `results/` | CSV tables for every result, `numbers.json` (every number quoted in the paper), raw replication-level output `main_runs.csv` |
| `figures/` | Every data figure in PNG (300 dpi) and PDF |
| `figures_static/` | Conceptual framework diagram (Graphviz source `framework.dot`) |

Tested with Python 3.11-3.12, NumPy 2.x, pandas 2.x, SciPy 1.13+, NetworkX 3.x, SALib 1.5, Matplotlib 3.9.

## 2. Repository layout

```
alignment_abm/
  model.py         agents, network, teams, pathologies, SD stocks, one semester, experiment driver
  analysis.py      paired (common-random-number) statistics, effect sizes, Holm correction
  calibration.py   pattern-oriented calibration (patterns P1-P2)
  validation.py    extreme-condition tests (E1-E7) and pattern checks (P1-P4)
  sensitivity.py   LHS + PRCC, Sobol indices (SALib), two-way grids, structural alternatives
  planner.py       instructor tool: engagement-anchored teams from a class roster (CSV)
tests/test_model.py  unit and regression tests
run_all.py           reproduces all results and figures
AlignmentGap_ABM_step2.ipynb  guided walk-through notebook
```

## 3. Model description (ODD protocol summary; Grimm et al. 2020)

**Purpose.** To explore how an unobservable, identity-based instructor-student alignment gap affects
students' learning in a 16-week project-based design course, and to compare low-cost instructor levers
(team formation rule; accountability structures) that use observable information only.

**Entities and state variables.**
*Students (24).* Hidden alignment state A_i in {M, P, A}; observed engagement score E_i in [0,1] and state
L_i in {passive, neutral, proactive}; identity-mismatch vector on four dimensions (gender, race/ethnicity,
age/career stage, language/accent) and identity distance D_i; introversion, stress, language barrier,
self-efficacy, ability; team id; cumulative learning.
*Class (system-dynamics stocks).* Instructor responsiveness Q and classroom climate C.
*Environment.* Homophilous small-world peer network; course calendar (individual work in weeks 1-4, 8 and 16;
project 1 in weeks 5-7; project 2 in weeks 9-15).

**Process overview and scheduling (each week).** (1) form or dissolve teams; (2) draw team pathologies
(loafing, conflict); (3) update hidden alignment (forward/backward, complex contagion, Eqs. A1-A3);
(4) update engagement (Eqs. E1-E2); (5) compute learning gain (Eq. L1); (6) update stocks Q and C (Eqs. Q1, C1).

**Design concepts.** *Emergence:* class-level learning, gaps, and alignment composition. *Interaction:*
weighted peer ties (teammates > network neighbours). *Stochasticity:* initial class, weekly noise,
transitions, pathologies. *Observation:* instructors observe engagement only; alignment is never used for
decisions. *Collectives:* teams. *Feedback:* R1 (engagement -> Q -> engagement), R2 (misalignment ->
climate -> backward transitions -> misalignment).

**Initialisation.** Initial alignment shares (25/50/25%) are matched exactly within each class by ranking a
latent propensity that decreases with identity distance. Engagement cut points are calibrated so the week-0
mix is 30/50/20% passive/neutral/proactive.

**Submodels.** Equations I1, E1-E2, A1-A3, T1-T2, L1, Q1, C1 are documented in the paper (Sec. 3) and in the
docstrings of `model.py`.

## 4. Experiments

* **Scenarios** (identical mechanics; only the team rule and accountability differ): no teams; random
  teams; engagement-anchored teams; random + accountability; anchored + accountability.
* **Common random numbers:** in replication r, every scenario sees the same class and random stream, so the
  paired difference is the unit of analysis.
* **Statistics:** mean ± 95% CI; paired t-test and Wilcoxon signed-rank test with Holm correction;
  Cohen's d_z (replication level) and d_s (student-level SD units). Following White et al. (2014), effect
  sizes, not p-values, are used to judge importance, because p-values in simulations shrink with the
  number of replications.
* **Calibration:** pattern-oriented (P1 small-group learning effect 0.3-0.7 SD; P2 alignment gap
  0.2-0.8 SD). All accepted parameter sets are re-run as an ensemble.
* **Sensitivity:** 14-parameter LHS + PRCC and Sobol indices; two-way grids (coupling x pathology;
  initial alignment x initial engagement); structural alternatives (network, contagion form, team size,
  SD feedback).

## 5. Instructor planning tool

```bash
python -m alignment_abm.planner my_roster.csv --team-size 4 --out teams.csv
```
`my_roster.csv` needs columns `name` and `engagement` (a 0-1 score from weeks 1-4, or the labels
passive/neutral/proactive). No identity or alignment information is requested or used.

## 6. License and citation

Code: MIT License. Please cite the paper above and the Zenodo DOI of the archived release.
