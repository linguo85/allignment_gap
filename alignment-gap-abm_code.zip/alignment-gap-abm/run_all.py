"""Reproduce every table, number, and figure in the manuscript.

    python run_all.py            # full run (about 4-5 minutes on 2 cores)
    python run_all.py --quick    # fast smoke run with fewer replications

Outputs go to results/ (CSV + JSON) and figures/ (PNG + PDF).
"""
from __future__ import annotations

import argparse
import json
import os
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from alignment_abm import analysis, calibration, sensitivity, validation
from alignment_abm.model import ALL_SCENARIOS, SCENARIOS, Params, run_experiment

ap = argparse.ArgumentParser()
ap.add_argument("--quick", action="store_true")
args = ap.parse_args()
Q = args.quick
os.makedirs("results", exist_ok=True)
os.makedirs("figures", exist_ok=True)
N_MAIN = 100 if Q else 500
N_CAL = 15 if Q else 40
N_ENS = 50 if Q else 200
N_LHS = 60 if Q else 500
N_SOBOL = 16 if Q else 64
N_GRID = 30 if Q else 150
T0 = time.time()
NUM = {}  # every number quoted in the manuscript


def log(msg):
    print(f"[{time.time() - T0:6.0f}s] {msg}", flush=True)


plt.rcParams.update({"font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9, "legend.fontsize": 8,
                     "xtick.labelsize": 8, "ytick.labelsize": 8, "axes.spines.top": False,
                     "axes.spines.right": False, "savefig.dpi": 300, "font.family": "DejaVu Sans"})
COL = {"no_teams": "#7a7a7a", "random": "#d9822b", "engagement_anchored": "#1f6fb2",
       "random_accountable": "#f0b27a", "anchored_accountable": "#7fb3e0"}
LAB = {"no_teams": "No teams", "random": "Random teams", "engagement_anchored": "Engagement-anchored teams",
       "random_accountable": "Random + accountability", "anchored_accountable": "Anchored + accountability"}


def save(fig, name):
    fig.savefig(f"figures/{name}.png", bbox_inches="tight")
    fig.savefig(f"figures/{name}.pdf", bbox_inches="tight")
    plt.close(fig)


# ------------------------------------------------------------------ 1. calibration
log("calibration")
C = calibration.run_calibration(Params(), n_runs=N_CAL)
C.to_csv("results/calibration_grid.csv", index=False)
best = C[C.accepted].sort_values("distance").iloc[0]
BASE = Params(n_runs=N_MAIN).with_(b_align=float(best.b_align), lam_misalign=float(best.lam_misalign),
                                   kappa_peer=float(best.kappa_peer))
NUM["calib"] = dict(best=dict(b_align=BASE.b_align, lam=BASE.lam_misalign, kappa=BASE.kappa_peer),
                    n_grid=int(len(C)), n_accepted=int(C.accepted.sum()))

# ------------------------------------------------------------------ 2. main experiment
log("main experiment")
R = run_experiment(BASE, seed0=2026, scenarios=ALL_SCENARIOS)
S, W, ST = R["S"], R["W"], R["students"]
S.to_csv("results/main_runs.csv", index=False)
analysis.summary_table(S, ALL_SCENARIOS).to_csv("results/main_summary.csv")
comps = {"anchored_vs_random": ("random", "engagement_anchored"),
         "random_vs_noteams": ("no_teams", "random"),
         "anchored_vs_noteams": ("no_teams", "engagement_anchored"),
         "randomacc_vs_random": ("random", "random_accountable"),
         "anchoredacc_vs_random": ("random", "anchored_accountable"),
         "anchoredacc_vs_anchored": ("engagement_anchored", "anchored_accountable"),
         "anchoredacc_vs_randomacc": ("random_accountable", "anchored_accountable")}
for name, (a, b) in comps.items():
    T = analysis.comparison_table(S, a, b)
    T.to_csv(f"results/compare_{name}.csv")
    NUM[name] = {k: {c: (None if pd.isna(v) else float(v)) for c, v in row.items() if c != "better if"}
                 for k, row in T.iterrows()}
NUM["means"] = {sc: {k: float(S.loc[S.scenario == sc, k].mean()) for k, *_ in analysis.METRICS}
                for sc in ALL_SCENARIOS}
NUM["ci"] = {sc: {k: float(analysis.ci95(S.loc[S.scenario == sc, k])[1]) for k, *_ in analysis.METRICS}
             for sc in ALL_SCENARIOS}
NUM["student_sd"] = float(S.learning_sd.mean())
NUM["n_runs"] = N_MAIN
NUM["tau"] = list(R["tau"])

# overlap between hidden alignment and observed engagement at week 0
ov = R["overlap"]
ov.to_csv("results/overlap_week0.csv")
counts = np.rint(ov.values * N_MAIN).astype(int)
pairs = np.array([(a, e) for a in range(3) for e in range(3)])
pooled = np.repeat(pairs, counts.ravel(), axis=0)
NUM["overlap"] = dict(rowpct=(ov.div(ov.sum(1), axis=0) * 100).round(1).values.tolist(),
                      spearman=float(spearmanr(pooled[:, 0], pooled[:, 1])[0]),
                      anchor_aligned=float(S.loc[S.scenario == "engagement_anchored", "anchor_aligned_share"].mean()))

# identity-distance analysis
ST["n_mismatch_grp"] = pd.cut(ST.dist, [-0.01, 0.2, 0.5, 0.8, 1.01], labels=["0-1", "2", "3", "4"])
idt = ST.groupby(["scenario", "n_mismatch_grp"], observed=True).agg(learning=("learning", "mean"),
                                                                    share_M0=("align0", lambda x: np.mean(x == 0)),
                                                                    n=("learning", "size")).reset_index()
idt.to_csv("results/identity_distance.csv", index=False)
corr_dist_align = spearmanr(ST[ST.scenario == "random"].dist, ST[ST.scenario == "random"].align0)[0]
NUM["identity"] = dict(spearman_dist_align=float(corr_dist_align),
                       table=idt.pivot(index="n_mismatch_grp", columns="scenario", values="learning").round(2).to_dict())

# ------------------------------------------------------------------ 3. calibrated ensemble
log("ensemble over accepted calibration sets")
ens = []
for _, row in C[C.accepted].iterrows():
    p = BASE.with_(b_align=float(row.b_align), lam_misalign=float(row.lam_misalign), kappa_peer=float(row.kappa_peer))
    d = sensitivity.paired_deltas(p, n_runs=N_ENS, seed0=31)
    ens.append({**row[["b_align", "lam_misalign", "kappa_peer", "P1", "P2"]].to_dict(), **d})
E = pd.DataFrame(ens)
E.to_csv("results/ensemble_deltas.csv", index=False)
NUM["ensemble"] = {k: dict(median=float(E[k].median()), min=float(E[k].min()), max=float(E[k].max()),
                           share_pos=float((E[k] > 0).mean())) for k in sensitivity.OUTPUTS}
NUM["ensemble"]["n"] = int(len(E))

# ------------------------------------------------------------------ 4. verification and validation
log("extreme-condition tests and pattern checks")
X = validation.extreme_condition_tests(BASE, n_runs=40 if Q else 100)
X.to_csv("results/extreme_tests.csv", index=False)
PCH = validation.pattern_checks(R)
PCH.to_csv("results/pattern_checks.csv", index=False)
NUM["extreme"] = X.to_dict(orient="records")
NUM["patterns"] = PCH.to_dict(orient="records")

# ------------------------------------------------------------------ 5. structural sensitivity
log("structural alternatives")
struct = {"Baseline (homophilous small world, complex contagion, teams of 4)": {},
          "Erdos-Renyi random network": dict(network="erdos_renyi"),
          "Small world without homophily": dict(network="small_world"),
          "Linear (simple) contagion": dict(contagion="linear"),
          "Teams of 3": dict(team_size=3),
          "Teams of 6": dict(team_size=6),
          "No team pathologies": dict(phi_loaf=0.0, c0_conflict=0.0, c1_conflict=0.0, c2_conflict=0.0),
          "SD feedback off (Q and climate frozen)": dict(rho_q=0.0, rho_c=0.0, beta_class=0.0),
          "Strong alignment-engagement coupling (b_align = 2)": dict(b_align=2.0)}
rows = []
for name, kw in struct.items():
    d = sensitivity.paired_deltas(BASE.with_(**kw), n_runs=N_ENS, seed0=55)
    rows.append(dict(variant=name, **d))
SV = pd.DataFrame(rows)
SV.to_csv("results/structural.csv", index=False)
NUM["structural"] = SV.to_dict(orient="records")

# ------------------------------------------------------------------ 6. global sensitivity
log("LHS + PRCC")
names = [s[0] for s in sensitivity.SA_SPACE]
XL = sensitivity.lhs(N_LHS, sensitivity.SA_SPACE, seed=3)
DL = sensitivity.evaluate_design(BASE, XL, names, n_runs=20 if not Q else 8)
DL.to_csv("results/lhs_design.csv", index=False)
PR = pd.concat([sensitivity.prcc(DL, names, o) for o in sensitivity.OUTPUTS])
PR.to_csv("results/prcc.csv", index=False)
NUM["lhs"] = {o: dict(share_pos=float((DL[o] > 0).mean()), median=float(DL[o].median())) for o in sensitivity.OUTPUTS}
NUM["prcc"] = {o: PR[PR.output == o].set_index("parameter").prcc.round(3).to_dict() for o in sensitivity.OUTPUTS}

log("interaction test")
INT = [sensitivity.interaction_test(DL, names, o) for o in sensitivity.OUTPUTS]
json.dump(INT, open("results/interaction_test.json", "w"), indent=1, default=float)
NUM["interactions"] = INT

log("two-way grids")
G1 = sensitivity.grid2d(BASE, "b_align", [0.25, 0.5, 1.0, 1.5, 2.0, 3.0], "pathology_scale", [0.0, 0.5, 1.0, 1.5, 2.0],
                        n_runs=N_GRID)
G1.to_csv("results/grid_coupling_pathology.csv", index=False)
G2 = sensitivity.grid2d(BASE, "init_misaligned", [0.10, 0.20, 0.30, 0.40, 0.50], "init_proactive", [0.10, 0.20, 0.30, 0.40],
                        n_runs=N_GRID)
G2.to_csv("results/grid_baseline_distribution.csv", index=False)
NUM["grid_baseline"] = dict(d_M0_min=float(G2.d_M0.min()), d_M0_max=float(G2.d_M0.max()),
                            d_avg_min=float(G2.d_avg.min()), d_avg_max=float(G2.d_avg.max()),
                            d_gap_min=float(G2.d_gap.min()), d_gap_max=float(G2.d_gap.max()))
NUM["grid_coupling"] = G1.round(3).to_dict(orient="records")

json.dump(NUM, open("results/numbers.json", "w"), indent=1, default=float)

# ------------------------------------------------------------------ 7. figures
log("figures")
# Fig: week-0 overlap
fig, ax = plt.subplots(figsize=(3.4, 2.5))
rp = ov.div(ov.sum(axis=1), axis=0) * 100
im = ax.imshow(rp.values, cmap="Blues", vmin=0, vmax=100)
ax.set_xticks(range(3), ["Passive", "Neutral", "Proactive"])
ax.set_yticks(range(3), ["Misaligned", "Partially\naligned", "Aligned"])
for i in range(3):
    for j in range(3):
        ax.text(j, i, f"{rp.values[i, j]:.0f}%", ha="center", va="center",
                color="white" if rp.values[i, j] > 55 else "black", fontsize=8.5)
ax.set_xlabel("Observed engagement (week 0)")
ax.set_ylabel("Hidden alignment (week 0)")
ax.spines[:].set_visible(False)
save(fig, "fig_overlap")

# Fig: weekly trajectories with 95% CI
def band(ax, col, ylabel, scen=SCENARIOS, ls="-"):
    for sc in scen:
        g = W[W.scenario == sc].groupby("week")[col]
        m = g.mean(); h = 1.96 * g.std() / np.sqrt(g.count())
        ax.plot(m.index, m.values, color=COL[sc], label=LAB[sc], lw=1.6, ls="--" if "accountable" in sc else "-")
        ax.fill_between(m.index, m - h, m + h, color=COL[sc], alpha=0.2, lw=0)
    for a, b in BASE.team_blocks:
        ax.axvspan(a - 0.5, b + 0.5, color="#000000", alpha=0.04, lw=0)
    ax.set_xlabel("Week"); ax.set_ylabel(ylabel); ax.set_xlim(1, 16)

fig, axs = plt.subplots(2, 2, figsize=(7.0, 4.8))
band(axs[0, 0], "avg_learning", "Average cumulative learning")
band(axs[0, 1], "misaligned", "Number of misaligned students")
band(axs[1, 0], "instructor_quality", "Instructor responsiveness Q (stock)")
band(axs[1, 1], "climate", "Classroom climate C (stock)")
for ax, l in zip(axs.flat, "abcd"):
    ax.set_title(f"({l})", loc="left")
axs[0, 0].legend(frameon=False, loc="upper left")
fig.tight_layout()
save(fig, "fig_trajectories")

# Fig: learning of each initial-alignment group by scenario (means with 95% CI)
fig, ax = plt.subplots(figsize=(7.0, 2.6))
groups = [("learning_M0", "Initially misaligned"), ("learning_P0", "Initially partially aligned"),
          ("learning_A0", "Initially aligned"), ("avg_learning", "Class average")]
wbar = 0.16
for k, sc in enumerate(ALL_SCENARIOS):
    ms = [S.loc[S.scenario == sc, g].mean() for g, _ in groups]
    hs = [analysis.ci95(S.loc[S.scenario == sc, g])[1] for g, _ in groups]
    ax.bar(np.arange(4) + (k - 2) * wbar, ms, wbar, yerr=hs, color=COL[sc], label=LAB[sc], capsize=1.5,
           hatch="//" if "accountable" in sc else None, edgecolor="white", lw=0.3)
ax.set_xticks(range(4), [g[1] for g in groups])
ax.set_ylabel("Cumulative learning (week 16)")
ax.set_ylim(15, None)
ax.legend(frameon=False, ncol=3, fontsize=7.5, loc="upper left")
save(fig, "fig_group_learning")

# Fig: paired differences, anchored - random
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.6))
A_ = S[S.scenario == "random"].sort_values("run")
keys = [("learning_M0", "Misaligned"), ("learning_P0", "Partially\naligned"), ("learning_A0", "Aligned"),
        ("avg_learning", "Average"), ("learning_gap", "Gap\n(A0 - M0)")]
for ax, sc, title in [(axs[0], "engagement_anchored", "(a) Engagement-anchored minus random"),
                      (axs[1], "anchored_accountable", "(b) Anchored + accountability minus random")]:
    B_ = S[S.scenario == sc].sort_values("run")
    data = [B_[k].values - A_[k].values for k, _ in keys]
    bp = ax.boxplot(data, widths=0.5, showfliers=False, patch_artist=True, medianprops=dict(color="black"))
    for patch in bp["boxes"]:
        patch.set_facecolor(COL[sc]); patch.set_alpha(0.7)
    ax.plot(range(1, 6), [d.mean() for d in data], "D", color="black", ms=3.5)
    ax.axhline(0, color="black", lw=0.6)
    ax.set_xticks(range(1, 6), [k[1] for k in keys])
    ax.set_title(title, loc="left")
axs[0].set_ylabel("Paired difference per replication")
fig.tight_layout()
save(fig, "fig_paired_diffs")

# Fig: identity distance gradient
fig, ax = plt.subplots(figsize=(3.4, 2.5))
for sc in ("no_teams", "random", "engagement_anchored", "anchored_accountable"):
    d = idt[idt.scenario == sc]
    ax.plot(d.n_mismatch_grp.astype(str), d.learning, marker="o", color=COL[sc], label=LAB[sc], ms=3.5, lw=1.4,
            ls="--" if "accountable" in sc else "-")
ax.set_xlabel("Identity dimensions differing from instructor")
ax.set_ylabel("Mean cumulative learning")
ax.legend(frameon=False, fontsize=7)
save(fig, "fig_identity")

# Fig: global sensitivity (PRCC and Sobol total order)
pretty = {"b_align": r"$\beta_A$ coupling", "lam_misalign": r"$\lambda$ instr. channel", "kappa_peer": r"$\kappa$ peer channel",
          "b_peer": r"$\beta_T$ peer engagement", "alpha_fwd": r"$\alpha_f$ forward", "alpha_bwd": r"$\alpha_b$ backward",
          "hill_nu": r"$\nu$ contagion shape", "phi_loaf": r"$\phi$ loafing", "c1_conflict": r"$c_1$ conflict (hetero.)",
          "c2_conflict": r"$c_2$ conflict (misal.)", "theta_identity": r"$\theta_D$ identity", "p_rewire": r"$p_{rw}$ rewiring",
          "init_misaligned": "initial % misaligned", "init_proactive": "initial % proactive"}
fig, axs = plt.subplots(1, 3, figsize=(7.2, 3.3), sharey=True)
order = PR[PR.output == "d_M0"].set_index("parameter").prcc.abs().sort_values().index
for ax, o, t in [(axs[0], "d_M0", "(a) Misaligned students' gain"), (axs[1], "d_gap", "(b) Change in learning gap"),
                 (axs[2], "d_avg", "(c) Class-average gain")]:
    v = PR[PR.output == o].set_index("parameter").reindex(order)
    ax.barh(range(len(order)), v.prcc, color=["#1f6fb2" if x > 0 else "#d9822b" for x in v.prcc])
    for yi, (val, pv) in enumerate(zip(v.prcc, v.p)):
        if pv < 0.05 / len(order):
            ax.text(val + (0.03 if val > 0 else -0.03), yi, "*", va="center", ha="left" if val > 0 else "right", fontsize=8)
    ax.axvline(0, color="black", lw=0.6); ax.set_xlim(-1, 1); ax.set_title(t, loc="left", fontsize=8.5)
    ax.set_xlabel("PRCC")
axs[0].set_yticks(range(len(order)), [pretty[k] for k in order])
fig.tight_layout()
save(fig, "fig_gsa")

# Fig: two-way grids
fig, axs = plt.subplots(1, 3, figsize=(7.3, 2.5))
def heat(ax, D, x, y, z, title, xl, yl, fmt="{:.1f}"):
    piv = D.pivot(index=y, columns=x, values=z)
    lim = np.nanmax(np.abs(piv.values))
    im = ax.imshow(piv.values, origin="lower", cmap="RdBu", vmin=-lim, vmax=lim, aspect="auto")
    ax.set_xticks(range(piv.shape[1]), [f"{v:g}" for v in piv.columns])
    ax.set_yticks(range(piv.shape[0]), [f"{v:g}" for v in piv.index])
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]):
            ax.text(j, i, fmt.format(piv.values[i, j]), ha="center", va="center", fontsize=6.5,
                    color="white" if abs(piv.values[i, j]) > 0.6 * lim else "black")
    ax.set_xlabel(xl); ax.set_ylabel(yl); ax.set_title(title, loc="left", fontsize=8.5)
    ax.spines[:].set_visible(False)
heat(axs[0], G1, "b_align", "pathology_scale", "d_M0", "(a) Misaligned gain", r"Coupling $\beta_A$", "Pathology scale")
heat(axs[1], G1, "b_align", "pathology_scale", "d_avg", "(b) Average gain", r"Coupling $\beta_A$", "Pathology scale")
G2p = G2.assign(init_misaligned=(G2.init_misaligned * 100).round().astype(int), init_proactive=(G2.init_proactive * 100).round().astype(int))
heat(axs[2], G2p, "init_misaligned", "init_proactive", "d_M0", "(c) Misaligned gain", "Initial % misaligned", "Initial % proactive")
fig.tight_layout()
save(fig, "fig_grids")

# Fig: calibration
fig, ax = plt.subplots(figsize=(3.4, 2.6))
ax.add_patch(plt.Rectangle((calibration.P1_BAND[0], calibration.P2_BAND[0]), np.diff(calibration.P1_BAND)[0],
                           np.diff(calibration.P2_BAND)[0], color="#1f6fb2", alpha=0.12, lw=0))
ax.scatter(C.P1, C.P2, c=np.where(C.accepted, "#1f6fb2", "#bbbbbb"), s=14)
ax.scatter([best.P1], [best.P2], marker="*", s=90, color="#d9822b", zorder=3, label="selected")
ax.set_xlabel("P1: team vs individual effect (SD)")
ax.set_ylabel("P2: aligned - misaligned gap (SD)")
ax.legend(frameon=False, fontsize=7)
save(fig, "fig_calibration")

log("done")
