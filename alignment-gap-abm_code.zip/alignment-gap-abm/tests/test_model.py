"""Unit tests (verification). Run with:  python -m pytest -q"""
import numpy as np
import pandas as pd
import pytest

from alignment_abm.model import (ALL_SCENARIOS, Params, calibrate_thresholds, contagion_response,
                                 draw_population, form_teams, run_experiment, run_semester)
from alignment_abm.planner import plan_teams

P = Params(n_runs=5)


def test_contagion_response_bounds_and_monotone():
    s = np.linspace(0, 1, 101)
    for c in ("complex", "linear"):
        h = contagion_response(s, P.with_(contagion=c))
        assert h[0] == pytest.approx(0) and h[-1] == pytest.approx(1)
        assert np.all(np.diff(h) >= -1e-12)


def test_population_matches_initial_alignment_shares():
    pop = draw_population(P, np.random.default_rng(1))
    counts = np.bincount(pop["align"], minlength=3)
    assert list(counts) == [6, 12, 6]
    assert pop["adj"].shape == (24, 24) and np.allclose(pop["adj"], pop["adj"].T)


@pytest.mark.parametrize("net", ["erdos_renyi", "small_world", "homophilous_small_world"])
def test_networks_connected_mean_degree(net):
    pop = draw_population(P.with_(network=net), np.random.default_rng(2))
    deg = pop["adj"].sum(1)
    assert deg.min() >= 1
    assert 2.5 <= deg.mean() <= 5.5


def test_threshold_calibration_hits_target_mix():
    tau = calibrate_thresholds(P)
    r = run_experiment(P, n_runs=40, scenarios=("random",), record_weekly=False)
    mix = r["students"].eng0.value_counts(normalize=True).sort_index().to_numpy()
    assert np.allclose(mix, P.target_eng_dist, atol=0.04)
    assert tau[0] < tau[1]


@pytest.mark.parametrize("sc", ["random", "engagement_anchored"])
def test_team_sizes_equal(sc):
    rng = np.random.default_rng(3)
    score = rng.random(24)
    state = np.digitize(score, [0.3, 0.8])
    team = form_teams(sc, state, score, P, rng)
    assert sorted(np.bincount(team)) == [4] * 6


def test_anchored_teams_have_one_anchor_each():
    rng = np.random.default_rng(4)
    score = rng.random(24)
    state = np.digitize(score, [0.3, 0.8])
    team = form_teams("engagement_anchored", state, score, P, rng)
    top6 = np.lexsort((-score, -state))[:6]
    assert len(set(team[top6])) == 6


def test_team_formation_ignores_hidden_alignment():
    """Shuffling hidden alignment must not change team assignment when engagement is held fixed."""
    rng = np.random.default_rng(5)
    score = rng.random(24)
    state = np.digitize(score, [0.3, 0.8])
    t1 = form_teams("engagement_anchored", state, score, P, np.random.default_rng(9))
    # form_teams has no alignment argument at all; this test documents that design decision
    t2 = form_teams("engagement_anchored", state.copy(), score.copy(), P, np.random.default_rng(9))
    assert np.array_equal(t1, t2)


def test_conservation_and_bounds_every_week():
    r = run_experiment(P, n_runs=3, scenarios=ALL_SCENARIOS)
    W = r["W"]
    assert ((W.misaligned + W.partially_aligned + W.aligned) == 24).all()
    assert ((W.passive + W.neutral + W.proactive) == 24).all()
    assert (W.instructor_quality.between(0, P.q_max + 1e-9)).all()
    assert (W.climate.between(0, 1)).all()
    assert (W.groupby(["run", "scenario"]).avg_learning.diff().dropna() >= 0).all()


def test_no_team_weeks_have_no_pathologies():
    r = run_experiment(P, n_runs=3, scenarios=("random",))
    W = r["W"]
    off = ~W.week.isin(list(range(5, 8)) + list(range(9, 16)))
    assert (W.loc[off, ["loafing", "conflict"]] == 0).all().all()


def test_reproducible_with_same_seed():
    a = run_experiment(P, n_runs=3, seed0=11, record_weekly=False)["S"]
    b = run_experiment(P, n_runs=3, seed0=11, record_weekly=False)["S"]
    pd.testing.assert_frame_equal(a, b)


def test_common_random_numbers_same_initial_class():
    r = run_experiment(P, n_runs=3, record_weekly=False)
    st = r["students"]
    for run in range(3):
        a0 = [st[(st.run == run) & (st.scenario == sc)].align0.to_numpy() for sc in ("no_teams", "random", "engagement_anchored")]
        e0 = [st[(st.run == run) & (st.scenario == sc)].eng0.to_numpy() for sc in ("no_teams", "random", "engagement_anchored")]
        assert all(np.array_equal(a0[0], x) for x in a0[1:])
        assert all(np.array_equal(e0[0], x) for x in e0[1:])


def test_planner_tool():
    roster = pd.DataFrame(dict(name=[f"s{i}" for i in range(12)], engagement=np.linspace(0, 1, 12)))
    out = plan_teams(roster, team_size=4)
    assert out.team.nunique() == 3 and out.anchor.sum() == 3
    assert out.groupby("team").anchor.sum().eq(1).all()


def test_no_backward_moves_without_misaligned_peers():
    """Regression test: aligned students surrounded by aligned peers must never move backward."""
    r = run_experiment(P.with_(align_dist=(0.0, 0.0, 1.0)), n_runs=5, record_weekly=False)
    assert r["S"].negative_conversion.max() == 0
