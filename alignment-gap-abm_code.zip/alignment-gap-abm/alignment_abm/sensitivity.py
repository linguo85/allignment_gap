"""Global and structural sensitivity analysis.

* Latin hypercube sampling + partial rank correlation coefficients (PRCC; Marino et al. 2008)
* Interaction test: second-order response-surface regression on the LHS design (all pairwise
  interactions), F-test against the main-effects model
* Variance-based Sobol indices (Saltelli et al. 2010) via SALib are available (`sobol`) but were not used
  in the paper: with a stochastic simulator they need far more replications per point than a
  2-core budget allows, and with few replications the indices are dominated by simulation noise
* Two-way grids for interactions and tipping points
* Alternative baseline (initial-state) distributions
* Structural alternatives (network topology, contagion form, team size, SD feedback on/off)

The response of interest is always the PAIRED difference engagement_anchored - random, computed
with common random numbers so that the variation reflects the parameters, not noise.
"""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor

import numpy as np
import pandas as pd
from scipy import stats

from .model import Params, run_experiment

# name, low, high, how it is applied
SA_SPACE = [
    ("b_align", 0.25, 2.0),
    ("lam_misalign", 0.05, 0.40),
    ("kappa_peer", 1.0, 3.5),
    ("b_peer", 0.5, 2.5),
    ("alpha_fwd", 0.10, 0.40),
    ("alpha_bwd", 0.02, 0.15),
    ("hill_nu", 1.0, 3.0),
    ("phi_loaf", 0.0, 0.5),
    ("c1_conflict", 0.0, 0.3),
    ("c2_conflict", 0.0, 0.4),
    ("theta_identity", 0.0, 3.0),
    ("p_rewire", 0.0, 0.5),
    ("init_misaligned", 0.10, 0.45),   # initial share M (A fixed at 0.25, P takes the rest)
    ("init_proactive", 0.10, 0.35),    # initial share proactive (passive fixed at 0.30)
]
OUTPUTS = ["d_avg", "d_M0", "d_gap", "d_final_mis"]


def params_from_vector(base: Params, names, x) -> Params:
    kw = {}
    for name, v in zip(names, x):
        if name == "pathology_scale":
            kw.update(phi_loaf=base.phi_loaf * v, c0_conflict=base.c0_conflict * v,
                      c1_conflict=base.c1_conflict * v, c2_conflict=base.c2_conflict * v)
        elif name == "init_misaligned":
            kw["align_dist"] = (float(v), float(0.75 - v), 0.25)
        elif name == "init_proactive":
            kw["target_eng_dist"] = (0.30, float(0.70 - v), float(v))
        else:
            kw[name] = float(v)
    return base.with_(**kw)


def paired_deltas(p: Params, n_runs=20, seed0=99, a="random", b="engagement_anchored") -> dict:
    r = run_experiment(p, seed0=seed0, n_runs=n_runs, scenarios=(a, b), record_weekly=False)
    S = r["S"]
    A = S[S.scenario == a].sort_values("run")
    B = S[S.scenario == b].sort_values("run")
    return dict(d_avg=(B.avg_learning.values - A.avg_learning.values).mean(),
                d_M0=(B.learning_M0.values - A.learning_M0.values).mean(),
                d_gap=(B.learning_gap.values - A.learning_gap.values).mean(),
                d_final_mis=(B.final_misaligned.values - A.final_misaligned.values).mean(),
                sd_student=A.learning_sd.mean())


def _worker(args):
    from . import model
    model.TAU_CLASSES = 300
    base, names, x, n_runs, seed = args
    return paired_deltas(params_from_vector(base, names, x), n_runs=n_runs, seed0=seed)


def evaluate_design(base: Params, X: np.ndarray, names, n_runs=20, workers=2, common_seed=True) -> pd.DataFrame:
    """Evaluate a design. With common_seed=True every design point reuses the same set of simulated
    classes and random streams, so differences between points reflect the parameters, not noise."""
    jobs = [(base, names, x, n_runs, 1000 if common_seed else 1000 + i) for i, x in enumerate(X)]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        res = list(ex.map(_worker, jobs, chunksize=4))
    out = pd.DataFrame(X, columns=names)
    return pd.concat([out, pd.DataFrame(res)], axis=1)


def lhs(n, space, seed=1):
    rng = np.random.default_rng(seed)
    d = len(space)
    u = (np.argsort(rng.random((n, d)), axis=0) + rng.random((n, d))) / n
    lo = np.array([s[1] for s in space]); hi = np.array([s[2] for s in space])
    return lo + u * (hi - lo)


def prcc(D: pd.DataFrame, inputs, output) -> pd.DataFrame:
    """Partial rank correlation coefficient of each input with the output."""
    R = D[inputs + [output]].rank().to_numpy()
    X, y = R[:, :-1], R[:, -1]
    rows = []
    for j, name in enumerate(inputs):
        others = np.delete(X, j, axis=1)
        Z = np.column_stack([np.ones(len(y)), others])
        rx = X[:, j] - Z @ np.linalg.lstsq(Z, X[:, j], rcond=None)[0]
        ry = y - Z @ np.linalg.lstsq(Z, y, rcond=None)[0]
        r, pval = stats.pearsonr(rx, ry)
        rows.append(dict(parameter=name, output=output, prcc=r, p=pval))
    return pd.DataFrame(rows)


def interaction_test(D: pd.DataFrame, inputs, output) -> dict:
    """Compare a main-effects regression with a full second-order model (squares + pairwise products)
    on standardised inputs. Returns R^2 of both models, the F-test for the added terms, and the
    strongest interaction terms."""
    from itertools import combinations
    from scipy import stats as st
    Z = (D[inputs] - D[inputs].mean()) / D[inputs].std()
    y = D[output].to_numpy(float)
    X1 = np.column_stack([np.ones(len(y)), Z.to_numpy()])
    pairs = list(combinations(inputs, 2))
    X2 = np.column_stack([X1] + [Z[a] * Z[b] for a, b in pairs] + [Z[a] ** 2 for a in inputs])
    def fit(X):
        b, *_ = np.linalg.lstsq(X, y, rcond=None)
        r = y - X @ b
        return b, r @ r
    b1, rss1 = fit(X1); b2, rss2 = fit(X2)
    tss = ((y - y.mean()) ** 2).sum()
    df1 = X2.shape[1] - X1.shape[1]; df2 = len(y) - X2.shape[1]
    F = ((rss1 - rss2) / df1) / (rss2 / df2)
    s2 = rss2 / df2
    cov = s2 * np.linalg.pinv(X2.T @ X2)
    se = np.sqrt(np.diag(cov))
    k0 = X1.shape[1]
    inter = pd.DataFrame(dict(term=[f"{a} x {b}" for a, b in pairs], coef=b2[k0:k0 + len(pairs)],
                              t=b2[k0:k0 + len(pairs)] / se[k0:k0 + len(pairs)]))
    inter = inter.reindex(inter.t.abs().sort_values(ascending=False).index)
    return dict(output=output, r2_main=1 - rss1 / tss, r2_second=1 - rss2 / tss, F=F, df1=df1, df2=df2,
                p=float(st.f.sf(F, df1, df2)), top=inter.head(5).round(3).to_dict(orient="records"))


def sobol(base: Params, N=64, n_runs=12, workers=2, seed=7):
    from SALib.analyze import sobol as sobol_an
    from SALib.sample import sobol as sobol_sample
    problem = dict(num_vars=len(SA_SPACE), names=[s[0] for s in SA_SPACE],
                   bounds=[[s[1], s[2]] for s in SA_SPACE])
    X = sobol_sample.sample(problem, N, calc_second_order=False, seed=seed)
    D = evaluate_design(base, X, problem["names"], n_runs=n_runs, workers=workers)
    res = {}
    for out in OUTPUTS:
        Si = sobol_an.analyze(problem, D[out].to_numpy(), calc_second_order=False, seed=seed)
        res[out] = pd.DataFrame(dict(parameter=problem["names"], S1=Si["S1"], S1_conf=Si["S1_conf"],
                                     ST=Si["ST"], ST_conf=Si["ST_conf"]))
    return D, res


def grid2d(base: Params, xname, xvals, yname, yvals, n_runs=40, workers=2) -> pd.DataFrame:
    names = [xname, yname]
    X = np.array([(x, y) for x in xvals for y in yvals], float)
    return evaluate_design(base, X, names, n_runs=n_runs, workers=workers)
