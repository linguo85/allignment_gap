"""Statistics for paired (common-random-number) scenario comparisons."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

# key, label, scale, better-if, is_learning_metric
METRICS = [
    ("avg_learning", "Average learning score", 1, "higher", True),
    ("learning_M0", "Learning of initially misaligned students", 1, "higher", True),
    ("learning_P0", "Learning of initially partially aligned students", 1, "higher", True),
    ("learning_A0", "Learning of initially aligned students", 1, "higher", True),
    ("learning_gap", "Alignment learning gap (A0 - M0)", 1, "lower", True),
    ("negative_conversion", "Negative conversion rate (%)", 100, "lower", False),
    ("final_misaligned", "Final number misaligned (of 24)", 1, "lower", False),
    ("final_aligned", "Final number aligned (of 24)", 1, "higher", False),
    ("final_proactive", "Final number proactive (of 24)", 1, "higher", False),
    ("instructor_quality", "Final instructor responsiveness Q", 1, "higher", False),
    ("loafing_rate", "Loafing incidence (% of member-weeks)", 100, "lower", False),
    ("conflict_rate", "Conflict incidence (% of member-weeks)", 100, "lower", False),
]


def ci95(x):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    if len(x) < 2:
        return (np.nan, np.nan)
    h = stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))
    return x.mean(), h


def summary_table(S: pd.DataFrame, scenarios) -> pd.DataFrame:
    rows = []
    for key, label, scale, _, _ in METRICS:
        row = {"Metric": label}
        for sc in scenarios:
            m, h = ci95(S.loc[S.scenario == sc, key] * scale)
            row[sc] = f"{m:.2f} ± {h:.2f}"
        rows.append(row)
    return pd.DataFrame(rows).set_index("Metric")


def holm(pvals):
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    running = 0.0
    m = len(p)
    for rank, idx in enumerate(order):
        running = max(running, min(1.0, (m - rank) * p[idx]))
        adj[idx] = running
    return adj


def comparison_table(S: pd.DataFrame, a: str, b: str) -> pd.DataFrame:
    """Paired comparison of scenario b against scenario a.

    Each replication r uses the same simulated class and random stream in both scenarios, so the
    replication-level difference d_r = x_b,r - x_a,r is the unit of analysis.

    Reported: means, mean difference with 95% CI, % change, paired t-test and Wilcoxon signed-rank
    p-values (Holm-adjusted across metrics), Cohen's d_z = mean(d)/sd(d) (standardised by the
    replication-to-replication variability of the difference), and, for learning metrics,
    d_s = mean(d)/mean within-class SD of individual learning scores, which expresses the
    difference in the student-level units used in education research.
    """
    A = S[S.scenario == a].sort_values("run")
    B = S[S.scenario == b].sort_values("run")
    sd_student = A["learning_sd"].to_numpy(float).mean()
    rows = []
    for key, label, scale, better, is_learning in METRICS:
        xa = A[key].to_numpy(float) * scale
        xb = B[key].to_numpy(float) * scale
        ok = ~(np.isnan(xa) | np.isnan(xb))
        xa, xb = xa[ok], xb[ok]
        d = xb - xa
        if d.std(ddof=1) > 0:
            t, pt = stats.ttest_rel(xb, xa)
            try:
                pw = stats.wilcoxon(d).pvalue
            except ValueError:
                pw = np.nan
            dz = d.mean() / d.std(ddof=1)
        else:
            pt = pw = 1.0 if d.mean() == 0 else 0.0
            dz = np.nan
        m, h = ci95(d)
        rows.append({"Metric": label, a: xa.mean(), b: xb.mean(), "Diff": m, "CI95": h,
                     "% change": 100 * m / xa.mean() if xa.mean() != 0 else np.nan,
                     "p_t": pt, "p_wilcoxon": pw, "d_z": dz,
                     "d_s": m / sd_student if is_learning else np.nan,
                     "better if": better})
    T = pd.DataFrame(rows).set_index("Metric")
    T["p_t_holm"] = holm(T["p_t"].fillna(1).to_numpy())
    T["p_w_holm"] = holm(T["p_wilcoxon"].fillna(1).to_numpy())
    return T


def team_effect_size(students: pd.DataFrame, a: str, b: str) -> float:
    """Student-level standardised mean difference in learning, scenario b vs a (pooled within-class SD)."""
    la = students[students.scenario == a]
    lb = students[students.scenario == b]
    sd = np.sqrt((la.groupby("run").learning.var().mean() + lb.groupby("run").learning.var().mean()) / 2)
    return (lb.learning.mean() - la.learning.mean()) / sd
