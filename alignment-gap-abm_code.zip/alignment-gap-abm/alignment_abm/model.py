"""
Hybrid agent-based / system-dynamics model of the identity-based alignment gap
in a 16-week project-based design course.

Revision step 2 (Nov 2026), responding to reviewers of MD-26-1447:

  * Hidden ALIGNMENT state (M = misaligned, P = partially aligned, A = aligned) is decoupled
    from the observable ENGAGEMENT state (passive / neutral / proactive). Engagement is driven
    by alignment AND by introversion, stress, language barrier, self-efficacy, peer engagement,
    instructor responsiveness, and team pathologies (Eq. E1).
  * Initial alignment depends on a multi-dimensional IDENTITY DISTANCE between each student and
    the instructor (gender, race/ethnicity, age/career stage, language/accent), not on a single
    abstract "bias" variable.
  * Peer network is CLUSTERED and HOMOPHILOUS (Watts-Strogatz small world with nodes ordered by
    identity), with Erdos-Renyi available for comparison.
  * Peer influence on alignment is NON-LINEAR (complex contagion, Hill-type response); a linear
    option is kept for comparison.
  * TEAM PATHOLOGIES: social loafing / free-riding (with a "sucker effect" on teammates) and
    relationship conflict, which lower engagement and learning and push alignment backward.
  * SYSTEM-DYNAMICS LAYER: two class-level stocks, instructor responsiveness Q and classroom
    climate C, updated by first-order adjustment equations (Eqs. Q1, C1).
  * Teams are formed from OBSERVED engagement only; hidden alignment is never used.
  * All scenarios share identical mechanics and parameters; only the team-formation rule differs.
    Common random numbers (same class, same random stream) are used across scenarios.

Plain NumPy + NetworkX; no Mesa dependency.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace

import networkx as nx
import numpy as np
import pandas as pd

ALIGN_LABELS = {0: "misaligned", 1: "partially_aligned", 2: "aligned"}
ENG_LABELS = {0: "passive", 1: "neutral", 2: "proactive"}
SCENARIOS = ("no_teams", "random", "engagement_anchored")
# 2x2 extension: team formation x accountability structures (peer evaluation + team charter)
EXT_SCENARIOS = ("random_accountable", "anchored_accountable")
ALL_SCENARIOS = SCENARIOS + EXT_SCENARIOS
IDENTITY_DIMS = ("gender", "race_ethnicity", "age_career_stage", "language_accent")


# --------------------------------------------------------------------------------------
# Parameters
# --------------------------------------------------------------------------------------
@dataclass(frozen=True)
class Params:
    # ---- class and course structure (Table 3) ----
    n_students: int = 24
    team_size: int = 4                       # 24 students -> 6 teams of 4
    n_weeks: int = 16
    team_blocks: tuple = ((5, 7), (9, 15))   # project 1: weeks 5-7, project 2: weeks 9-15

    # ---- identity distance and initial alignment (Eq. I1) ----
    # probability that a student differs from the instructor on each identity dimension
    p_mismatch: tuple = (0.75, 0.70, 0.60, 0.80)
    w_identity: tuple = (1.0, 1.0, 0.5, 1.0)  # relative weight of each dimension
    w_intersect: float = 0.5                  # extra weight when >= 2 dimensions differ
    theta_identity: float = 1.5               # strength of identity distance -> misalignment
    align_dist: tuple = (0.25, 0.50, 0.25)    # initial M, P, A shares (Table 1)

    # ---- engagement drivers (population distributions) ----
    introversion_beta: tuple = (2.0, 2.0)
    stress_beta: tuple = (2.0, 3.0)
    p_language_barrier: float = 0.20
    language_severity: tuple = (0.4, 1.0)
    efficacy_beta: tuple = (4.0, 2.0)

    # ---- engagement index (Eq. E1) ----
    b_align: float = 0.50     # alignment -> engagement coupling (calibrated; varied in Sec. 6)
    b_efficacy: float = 1.0
    b_introv: float = 1.0
    b_stress: float = 1.0
    b_lang: float = 1.5
    b_peer: float = 1.5
    b_instr: float = 1.0
    b_loaf: float = 0.8        # engagement penalty for a student who loafed last week
    b_sucker: float = 0.8      # penalty proportional to share of loafing teammates ("sucker effect")
    b_conflict: float = 0.8    # penalty for all members of a team in conflict last week
    sigma_eng: float = 0.30
    inertia: float = 0.30      # omega in Eq. E2
    target_eng_dist: tuple = (0.30, 0.50, 0.20)  # initial passive / neutral / proactive (Table 2)

    # ---- peer interaction structure ----
    network: str = "homophilous_small_world"   # | "small_world" | "erdos_renyi"
    net_mean_degree: int = 4
    p_rewire: float = 0.10
    w_team: float = 1.0
    w_net: float = 0.15
    w_ref: float = 3.0

    # ---- hidden alignment dynamics (Eqs. A1-A3) ----
    contagion: str = "complex"   # | "linear"
    hill_nu: float = 2.0         # steepness of the complex-contagion response
    hill_theta: float = 0.5      # half-saturation share of peers
    alpha_fwd: float = 0.25
    alpha_bwd: float = 0.05
    c_inst: float = 0.5          # institutional climate (exogenous, 0-1)
    beta_inst: float = 0.5
    beta_class: float = 0.5      # amplification of backward transitions by classroom climate stock
    chi_conflict: float = 0.5    # extra backward pressure during team conflict

    # ---- team pathologies (Eqs. T1-T2) ----
    phi_loaf: float = 0.25       # weekly loafing propensity scale
    loaf_size_exp: float = 1.0   # loafing grows with team size (Latane et al.; Karau & Williams)
    delta_loaf: float = 0.5      # share of the week's learning lost by a loafer
    c0_conflict: float = 0.04    # baseline weekly relationship-conflict probability per team
    c1_conflict: float = 0.15    # + alignment heterogeneity within the team
    c2_conflict: float = 0.20    # + share of misaligned members
    delta_conflict: float = 0.5  # reduction of the peer-learning channel during conflict
    acc_loaf: float = 0.5        # loafing multiplier under accountability (peer evaluation)
    acc_conflict: float = 0.5    # conflict multiplier under accountability (team charter)

    # ---- learning (Eq. L1) ----
    gamma: tuple = (0.60, 1.00, 1.30)   # gain multiplier by engagement state (Table 2; ICAP ordering)
    ability_sd: float = 0.30            # prior preparation / ability heterogeneity
    lam_misalign: float = 0.10          # instructor-channel loss for a fully misaligned student (calibrated)
    kappa_peer: float = 3.00            # strength of the peer-learning channel (calibrated)
    gain_noise_sd: float = 0.05

    # ---- system-dynamics stocks (Eqs. Q1, C1) ----
    q_max: float = 0.4
    rho_q: float = 0.3
    eta_climate_q: float = 0.25   # hostile climate erodes instructor responsiveness
    rho_c: float = 0.3

    # ---- experiment ----
    n_runs: int = 200

    def with_(self, **kw) -> "Params":
        return replace(self, **kw)


# --------------------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------------------
def logistic(z):
    return 1.0 / (1.0 + np.exp(-z))


def contagion_response(share, p: Params):
    """Peer-influence response h(s) with h(0)=0 and h(1)=1 (Eq. A3)."""
    share = np.clip(share, 0.0, 1.0)
    if p.contagion == "linear":
        return share
    th = p.hill_theta ** p.hill_nu
    sn = share ** p.hill_nu
    return sn / (sn + th) * (1.0 + th)


def identity_distance(mismatch: np.ndarray, p: Params) -> np.ndarray:
    """Weighted share of identity dimensions on which a student differs from the instructor,
    plus an intersectionality term when two or more dimensions differ (Eq. I1)."""
    w = np.asarray(p.w_identity)
    base = mismatch @ w / w.sum()
    multi = (mismatch.sum(1) >= 2).astype(float)
    return (base + p.w_intersect * multi * base) / (1.0 + p.w_intersect)


def build_network(p: Params, order_key: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    n = p.n_students
    seed = int(rng.integers(1_000_000_000))
    if p.network == "erdos_renyi":
        G = nx.erdos_renyi_graph(n, p.net_mean_degree / (n - 1), seed=seed)
        comps = list(nx.connected_components(G))
        for c1, c2 in zip(comps[:-1], comps[1:]):
            G.add_edge(next(iter(c1)), next(iter(c2)))
        return nx.to_numpy_array(G, nodelist=range(n))
    G = nx.connected_watts_strogatz_graph(n, p.net_mean_degree, p.p_rewire, seed=seed)
    A = nx.to_numpy_array(G, nodelist=range(n))
    if p.network == "homophilous_small_world":
        # place students on the ring in order of identity profile, so neighbours are similar
        pos = np.argsort(np.argsort(order_key))  # student i sits at ring position pos[i]
        A = A[np.ix_(pos, pos)]
    return A


def draw_population(p: Params, rng: np.random.Generator) -> dict:
    """Draw one class: identity profile, hidden alignment, engagement drivers, ability, network."""
    n = p.n_students
    mismatch = (rng.random((n, len(IDENTITY_DIMS))) < np.asarray(p.p_mismatch)).astype(float)
    dist = identity_distance(mismatch, p)
    # latent alignment propensity; rank within class so that the class matches align_dist exactly
    latent = -p.theta_identity * (dist - dist.mean()) + rng.normal(0, 1, n)
    counts = np.round(np.asarray(p.align_dist) * n).astype(int)
    counts[-1] = n - counts[:-1].sum()
    align = np.empty(n, dtype=int)
    order = np.argsort(latent)  # lowest propensity -> misaligned
    align[order] = np.repeat([0, 1, 2], counts)

    introv = rng.beta(*p.introversion_beta, n)
    stress = rng.beta(*p.stress_beta, n)
    lang = (rng.random(n) < p.p_language_barrier) * rng.uniform(*p.language_severity, n)
    efficacy = rng.beta(*p.efficacy_beta, n)
    ability = np.clip(rng.normal(1.0, p.ability_sd, n), 0.25, 1.75)
    # homophily key: identity profile (binary code) with a small jitter
    key = mismatch @ (2.0 ** np.arange(mismatch.shape[1])) + rng.random(n) * 0.5
    adj = build_network(p, key, rng)
    return dict(align=align, mismatch=mismatch, dist=dist, introv=introv, stress=stress,
                lang=lang, efficacy=efficacy, ability=ability, adj=adj)


def static_index(p: Params, pop: dict, align: np.ndarray) -> np.ndarray:
    """Peer- and instructor-independent part of the engagement index (centred drivers)."""
    a = align / 2.0
    return (p.b_align * (a - 0.5)
            + p.b_efficacy * (pop["efficacy"] - 2 / 3)
            - p.b_introv * (pop["introv"] - 0.5)
            - p.b_stress * (pop["stress"] - 0.4)
            - p.b_lang * pop["lang"])


_TAU_CACHE: dict = {}
TAU_CLASSES = 1000  # classes simulated to calibrate the engagement cut points


def calibrate_thresholds(p: Params, n_classes: int | None = None, seed: int = 12345) -> tuple:
    """Cut points tau1, tau2 so that the week-0 engagement mix matches target_eng_dist."""
    n_classes = TAU_CLASSES if n_classes is None else n_classes
    key = (p.n_students, p.align_dist, p.p_mismatch, p.w_identity, p.w_intersect, p.theta_identity,
           p.b_align, p.b_efficacy, p.b_introv, p.b_stress, p.b_lang, p.sigma_eng,
           p.introversion_beta, p.stress_beta, p.p_language_barrier, p.language_severity,
           p.efficacy_beta, p.target_eng_dist, n_classes)
    if key in _TAU_CACHE:
        return _TAU_CACHE[key]
    rng = np.random.default_rng(seed)
    q = p.with_(network="erdos_renyi")  # network irrelevant here; ER is fastest
    scores = []
    for _ in range(n_classes):
        pop = draw_population(q, rng)
        z = static_index(p, pop, pop["align"]) + rng.normal(0, p.sigma_eng, p.n_students)
        scores.append(logistic(z))
    scores = np.concatenate(scores)
    t = (float(np.quantile(scores, p.target_eng_dist[0])),
         float(np.quantile(scores, p.target_eng_dist[0] + p.target_eng_dist[1])))
    _TAU_CACHE[key] = t
    return t


def to_state(score, tau):
    return np.where(score < tau[0], 0, np.where(score < tau[1], 1, 2))


# --------------------------------------------------------------------------------------
# Team formation: uses OBSERVED engagement only
# --------------------------------------------------------------------------------------
def form_teams(scenario: str, eng_state, eng_score, p: Params, rng) -> np.ndarray:
    """Return a team id per student (-1 = no team)."""
    n = p.n_students
    n_teams = n // p.team_size
    scenario = base_formation(scenario)
    if scenario == "no_teams":
        return -np.ones(n, dtype=int)
    if scenario == "random":
        order = rng.permutation(n)
        team = np.empty(n, dtype=int)
        team[order] = np.arange(n) % n_teams
        return team
    if scenario == "engagement_anchored":
        team = -np.ones(n, dtype=int)
        ranked = np.lexsort((-eng_score, -eng_state))  # proactive first, then by score
        team[ranked[:n_teams]] = np.arange(n_teams)    # one anchor per team
        rest = [i for i in np.argsort(-eng_score) if team[i] < 0]
        order = list(range(n_teams - 1, -1, -1))       # weakest anchor team picks first
        while rest:                                    # snake draft balances team engagement
            for t in order:
                if not rest:
                    break
                team[rest.pop(0)] = t
            order = order[::-1]
        return team
    raise ValueError(scenario)


def base_formation(scenario: str) -> str:
    return {"random_accountable": "random", "anchored_accountable": "engagement_anchored"}.get(scenario, scenario)


def is_accountable(scenario: str) -> bool:
    return scenario.endswith("_accountable")


def peer_weights(team, adj, p: Params) -> np.ndarray:
    same = (team[:, None] == team[None, :]) & (team[:, None] >= 0)
    np.fill_diagonal(same, False)
    W = np.where(same, p.w_team, adj * p.w_net)
    np.fill_diagonal(W, 0.0)
    return W


# --------------------------------------------------------------------------------------
# One semester
# --------------------------------------------------------------------------------------
def run_semester(scenario: str, p: Params, tau: tuple, pop: dict, rng: np.random.Generator,
                 record_weekly: bool = True) -> dict:
    n = p.n_students
    align = pop["align"].copy()
    align0 = align.copy()
    eng_score = logistic(static_index(p, pop, align) + rng.normal(0, p.sigma_eng, n))
    eng_state = to_state(eng_score, tau)
    eng0 = eng_state.copy()

    q = 0.0                               # SD stock: instructor responsiveness
    climate = float(np.mean(align == 0))  # SD stock: classroom climate (share misaligned, smoothed)
    learning = np.zeros(n)
    backward_ever = np.zeros(n, dtype=bool)
    team = -np.ones(n, dtype=int)
    loaf_prev = np.zeros(n)
    sucker_prev = np.zeros(n)
    conflict_prev = np.zeros(n)
    loaf_weeks = 0.0
    conflict_weeks = 0.0
    team_weeks = 0
    anchors_aligned = []
    weekly = []
    starts = [a for a, _ in p.team_blocks]

    def in_block(w):
        return any(a <= w <= b for a, b in p.team_blocks)

    for week in range(1, p.n_weeks + 1):
        # ---- team structure ----
        if week in starts:
            team = form_teams(scenario, eng_state, eng_score, p, rng)
            if base_formation(scenario) == "engagement_anchored":
                idx = np.lexsort((-eng_score, -eng_state))[: n // p.team_size]
                anchors_aligned.append(np.mean(align[idx] == 2))
        elif not in_block(week):
            team = -np.ones(n, dtype=int)
        in_team = team >= 0

        W = peer_weights(team, pop["adj"], p)
        wsum = W.sum(1)
        intensity = np.minimum(1.0, wsum / p.w_ref)
        safe = np.where(wsum > 0, wsum, 1.0)

        # ---- team pathologies this week (Eqs. T1-T2) ----
        loaf = np.zeros(n)
        conflict = np.zeros(n)
        share_loafers = np.zeros(n)
        if in_team.any():
            team_weeks += 1
            size_factor = ((p.team_size - 1) / 3.0) ** p.loaf_size_exp
            acc_l = p.acc_loaf if is_accountable(scenario) else 1.0
            acc_c = p.acc_conflict if is_accountable(scenario) else 1.0
            p_loaf = np.clip(acc_l * p.phi_loaf * (1.0 - eng_score) * size_factor, 0, 1) * in_team
            loaf = (rng.random(n) < p_loaf).astype(float)
            for t in np.unique(team[in_team]):
                mem = team == t
                a_sc = align[mem] / 2.0
                p_conf = np.clip(acc_c * (p.c0_conflict + p.c1_conflict * 2 * a_sc.std()
                                          + p.c2_conflict * np.mean(align[mem] == 0)), 0, 1)
                if rng.random() < p_conf:
                    conflict[mem] = 1.0
                k = mem.sum()
                if k > 1:
                    share_loafers[mem] = (loaf[mem].sum() - loaf[mem]) / (k - 1)
            loaf_weeks += loaf[in_team].mean()
            conflict_weeks += conflict[in_team].mean()

        # ---- hidden alignment update (Eqs. A1-A3) ----
        share_aligned = (W @ (align == 2)) / safe
        share_mis = (W @ (align == 0)) / safe
        p_fwd = np.clip(p.alpha_fwd * contagion_response(share_aligned, p) * intensity, 0, 1)
        amp = (1 + p.beta_inst * p.c_inst) * (1 + p.beta_class * climate) * (1 + p.chi_conflict * conflict)
        p_bwd = np.clip(p.alpha_bwd * contagion_response(share_mis, p) * intensity * amp, 0, 1)
        # one uniform draw per student: [0, p_fwd) -> forward, [p_fwd, p_fwd + p_bwd) -> backward.
        # Forward is impossible for aligned students and backward impossible for misaligned ones,
        # so those probabilities are zeroed first (otherwise a "forward" draw of an aligned
        # student would be misread as a backward move).
        p_fwd = p_fwd * (align < 2)
        p_bwd = np.minimum(p_bwd * (align > 0), 1.0 - p_fwd)
        u = rng.random(n)
        fwd = u < p_fwd
        bwd = (u >= p_fwd) & (u < p_fwd + p_bwd)
        align = align + fwd.astype(int) - bwd.astype(int)
        backward_ever |= bwd

        # ---- engagement update (Eqs. E1-E2) ----
        peer_eng = np.where(wsum > 0, (W @ eng_score) / safe, 0.5)
        z = (static_index(p, pop, align)
             + p.b_peer * intensity * (peer_eng - 0.5)
             + p.b_instr * q
             - p.b_loaf * loaf_prev - p.b_sucker * sucker_prev - p.b_conflict * conflict_prev
             + rng.normal(0, p.sigma_eng, n))
        eng_score = (1 - p.inertia) * eng_score + p.inertia * logistic(z)
        eng_state = to_state(eng_score, tau)

        # ---- learning gain (Eq. L1) ----
        m = 1.0 - align / 2.0
        gamma = np.asarray(p.gamma)[eng_state]
        instructor_channel = (1 + q) * (1 - p.lam_misalign * m)
        peer_channel = (p.kappa_peer * intensity * np.where(wsum > 0, (W @ eng_score) / safe, 0.0)
                        * (1 - p.delta_conflict * conflict))
        gain = pop["ability"] * gamma * (instructor_channel + peer_channel) * (1 - p.delta_loaf * loaf)
        gain *= 1 + rng.normal(0, p.gain_noise_sd, n)
        learning += np.maximum(gain, 0)

        # ---- system-dynamics stocks (Eqs. Q1, C1) ----
        mis_share = float(np.mean(align == 0))
        q = q + p.rho_q * (p.q_max * max(eng_score.mean() - p.eta_climate_q * climate, 0.0) - q)
        climate = climate + p.rho_c * (mis_share - climate)

        loaf_prev, sucker_prev, conflict_prev = loaf, share_loafers, conflict

        if record_weekly:
            weekly.append(dict(
                week=week,
                misaligned=int((align == 0).sum()), partially_aligned=int((align == 1).sum()),
                aligned=int((align == 2).sum()),
                passive=int((eng_state == 0).sum()), neutral=int((eng_state == 1).sum()),
                proactive=int((eng_state == 2).sum()),
                avg_learning=learning.mean(),
                learning_M0=learning[align0 == 0].mean(), learning_A0=learning[align0 == 2].mean(),
                instructor_quality=q, climate=climate, mean_engagement=eng_score.mean(),
                loafing=loaf[in_team].mean() if in_team.any() else 0.0,
                conflict=conflict[in_team].mean() if in_team.any() else 0.0))

    sd_pool = learning.std(ddof=1)
    gap = learning[align0 == 2].mean() - learning[align0 == 0].mean()
    p0 = align0 == 1
    summary = dict(
        negative_conversion=backward_ever.mean(),
        p0_to_misaligned=(align[p0] == 0).mean(),
        avg_learning=learning.mean(),
        learning_M0=learning[align0 == 0].mean(),
        learning_P0=learning[align0 == 1].mean(),
        learning_A0=learning[align0 == 2].mean(),
        learning_gap=gap,
        gap_sd_units=gap / sd_pool if sd_pool > 0 else np.nan,
        learning_sd=sd_pool,
        final_misaligned=int((align == 0).sum()), final_aligned=int((align == 2).sum()),
        final_proactive=int((eng_state == 2).sum()),
        instructor_quality=q, final_climate=climate,
        loafing_rate=loaf_weeks / team_weeks if team_weeks else 0.0,
        conflict_rate=conflict_weeks / team_weeks if team_weeks else 0.0,
        anchor_aligned_share=float(np.mean(anchors_aligned)) if anchors_aligned else np.nan,
    )
    out = dict(summary=summary, align0=align0, eng0=eng0, learning=learning, dist=pop["dist"])
    if record_weekly:
        out["weekly"] = pd.DataFrame(weekly)
    return out


# --------------------------------------------------------------------------------------
# Experiment driver (common random numbers)
# --------------------------------------------------------------------------------------
def run_experiment(p: Params, seed0: int = 2026, scenarios=SCENARIOS, record_weekly=True,
                   n_runs: int | None = None):
    n_runs = p.n_runs if n_runs is None else n_runs
    tau = calibrate_thresholds(p)
    summaries, weeklies, overlap, students = [], [], [], []
    for r in range(n_runs):
        pop = draw_population(p, np.random.default_rng([seed0, r, 0]))  # same class in every scenario
        for sc in scenarios:
            rng = np.random.default_rng([seed0, r, 1])                    # same random stream
            out = run_semester(sc, p, tau, pop, rng, record_weekly=record_weekly)
            summaries.append(dict(run=r, scenario=sc, **out["summary"]))
            if record_weekly:
                w = out["weekly"]; w["run"] = r; w["scenario"] = sc
                weeklies.append(w)
            students.append(pd.DataFrame(dict(run=r, scenario=sc, align0=out["align0"], eng0=out["eng0"],
                                              learning=out["learning"], dist=out["dist"])))
            if sc == scenarios[0]:
                overlap.append(pd.crosstab(pd.Series(out["align0"]).map(ALIGN_LABELS),
                                           pd.Series(out["eng0"]).map(ENG_LABELS)))
    S = pd.DataFrame(summaries)
    Wk = pd.concat(weeklies, ignore_index=True) if weeklies else None
    ov = (pd.concat(overlap).groupby(level=0).sum()
          .reindex(index=list(ALIGN_LABELS.values()), columns=list(ENG_LABELS.values())).fillna(0))
    return dict(S=S, W=Wk, overlap=ov / len(overlap), tau=tau, students=pd.concat(students, ignore_index=True))
