"""Instructor team-planning helper.

Applies the engagement-anchored rule studied in the paper to a real class roster, using only
observable engagement. No identity or alignment information is requested or used.

Roster CSV columns:
    name         student identifier
    engagement   observed engagement score in [0, 1] (e.g., share of in-class activities,
                 discussion posts, and office-hour visits in weeks 1-4, rescaled), OR a
                 category "passive" / "neutral" / "proactive"

Usage:
    python -m alignment_abm.planner roster.csv --team-size 4 --out teams.csv
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from .model import Params, form_teams

CAT = {"passive": 0, "neutral": 1, "proactive": 2}


def plan_teams(roster: pd.DataFrame, team_size: int = 4, cut=(1 / 3, 2 / 3)) -> pd.DataFrame:
    df = roster.copy()
    if df["engagement"].dtype == object:
        state = df["engagement"].str.lower().map(CAT).to_numpy()
        score = state / 2.0 + np.random.default_rng(0).random(len(df)) * 1e-3  # tie-break
    else:
        score = df["engagement"].astype(float).to_numpy()
        state = np.where(score < cut[0], 0, np.where(score < cut[1], 1, 2))
    n = len(df)
    if n % team_size:
        raise ValueError(f"{n} students cannot be split evenly into teams of {team_size}; "
                         "adjust team_size or add/remove a seat (teams of mixed size are not supported).")
    p = Params(n_students=n, team_size=team_size)
    team = form_teams("engagement_anchored", state, score, p, np.random.default_rng(0))
    ranked = np.lexsort((-score, -state))[: n // team_size]
    df["team"] = team + 1
    df["anchor"] = False
    df.loc[df.index[ranked], "anchor"] = True
    df["engagement_state"] = pd.Series(state, index=df.index).map({v: k for k, v in CAT.items()})
    return df.sort_values(["team", "anchor"], ascending=[True, False])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("roster")
    ap.add_argument("--team-size", type=int, default=4)
    ap.add_argument("--out", default="teams.csv")
    a = ap.parse_args()
    out = plan_teams(pd.read_csv(a.roster), a.team_size)
    out.to_csv(a.out, index=False)
    print(out.to_string(index=False))


if __name__ == "__main__":
    main()
