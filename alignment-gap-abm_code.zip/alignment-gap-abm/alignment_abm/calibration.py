"""Pattern-oriented calibration (Grimm et al. 2005; Railsback & Grimm 2019).

Three parameters that cannot be measured directly are tuned so that the model reproduces two
empirical patterns at once:

  P1  Small-group learning effect. Random teams vs. individual work should raise achievement by a
      moderate student-level effect size. Target band 0.3-0.7 SD around the meta-analytic
      estimate of 0.51 for small-group learning in undergraduate STEM (Springer et al. 1999).
  P2  Size of the alignment-related learning gap. The difference between initially aligned and
      initially misaligned students under random teaming should be small-to-moderate
      (0.2-0.8 SD), consistent with instructor-student identity-match effects that are real but
      far from order-of-magnitude (Dee 2004; Fairlie et al. 2014).

The calibration grid is deliberately coarse; every accepted parameter set is retained so that the
main results can be reported across the accepted ensemble, not only at one chosen point.
"""
from __future__ import annotations

import itertools

import numpy as np
import pandas as pd

from .analysis import team_effect_size
from .model import Params, run_experiment

GRID = dict(b_align=(0.5, 0.75, 1.0, 1.25),
            lam_misalign=(0.1, 0.2, 0.3),
            kappa_peer=(1.5, 2.0, 2.5, 3.0))
P1_BAND = (0.3, 0.7)
P2_BAND = (0.2, 0.8)


def evaluate(p: Params, n_runs=40, seed0=777) -> dict:
    r = run_experiment(p, seed0=seed0, n_runs=n_runs, scenarios=("no_teams", "random"), record_weekly=False)
    S = r["S"]
    P1 = team_effect_size(r["students"], "no_teams", "random")
    P2 = S.loc[S.scenario == "random", "gap_sd_units"].mean()
    return dict(P1=P1, P2=P2)


def run_calibration(base: Params, n_runs=40) -> pd.DataFrame:
    rows = []
    keys = list(GRID)
    for vals in itertools.product(*GRID.values()):
        kw = dict(zip(keys, vals))
        res = evaluate(base.with_(**kw), n_runs=n_runs)
        rows.append({**kw, **res})
    C = pd.DataFrame(rows)
    C["accepted"] = C.P1.between(*P1_BAND) & C.P2.between(*P2_BAND)
    C["distance"] = (np.abs(C.P1 - np.mean(P1_BAND)) / (np.diff(P1_BAND)[0] / 2)
                     + np.abs(C.P2 - np.mean(P2_BAND)) / (np.diff(P2_BAND)[0] / 2))
    return C
