"""Verification (extreme-condition tests) and pattern-oriented validation checks.

Each extreme-condition test states an expected behaviour that follows from the model logic, runs the
model under that condition, and reports whether the expectation holds. These complement the unit tests
in tests/test_model.py (conservation, bounds, reproducibility, hidden-state independence of team
formation, threshold calibration).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .analysis import team_effect_size
from .model import Params, run_experiment


def _means(p, n_runs=60, scenarios=("no_teams", "random", "engagement_anchored"), seed0=4242):
    r = run_experiment(p, seed0=seed0, n_runs=n_runs, scenarios=scenarios, record_weekly=False)
    return r, r["S"].groupby("scenario").mean(numeric_only=True)


def extreme_condition_tests(base: Params, n_runs=60) -> pd.DataFrame:
    rows = []

    # E1: no peer influence on alignment -> no alignment transitions in any scenario
    r, g = _means(base.with_(alpha_fwd=0.0, alpha_bwd=0.0), n_runs)
    ok = (g.negative_conversion.max() == 0) and np.allclose(g.final_misaligned, round(base.align_dist[0] * 24))
    rows.append(("E1", "alpha_fwd = alpha_bwd = 0", "No alignment transitions; final counts equal initial counts",
                 f"neg. conversion = {g.negative_conversion.max():.3f}; final M = {g.final_misaligned.mean():.2f}", ok))

    # E2: everyone aligned -> no misaligned peers, so no backward transitions
    r, g = _means(base.with_(align_dist=(0.0, 0.0, 1.0)), n_runs)
    ok = g.negative_conversion.max() == 0
    rows.append(("E2", "All students initially aligned", "No backward transitions (no misaligned peers)",
                 f"neg. conversion = {g.negative_conversion.max():.3f}", ok))

    # E3: alignment has no effect on engagement or learning -> no learning gap
    r, g = _means(base.with_(b_align=0.0, lam_misalign=0.0), n_runs)
    gap = r["S"].groupby("scenario").gap_sd_units.agg(["mean", "sem"])
    ok = bool((gap["mean"].abs() < 3 * gap["sem"] + 0.05).all())
    rows.append(("E3", "b_align = 0 and lambda = 0", "Alignment learning gap is zero within noise",
                 "gap (SD units) = " + ", ".join(f"{v:.3f}" for v in gap["mean"]), ok))

    # E4: no peer learning, no peer engagement contagion, no pathologies, alignment irrelevant
    #     -> teams cannot change learning
    q = base.with_(kappa_peer=0.0, b_peer=0.0, phi_loaf=0.0, c0_conflict=0.0, c1_conflict=0.0,
                   c2_conflict=0.0, b_align=0.0, lam_misalign=0.0)
    r, g = _means(q, n_runs)
    spread = g.avg_learning.max() - g.avg_learning.min()
    ok = spread / g.avg_learning.mean() < 0.01
    rows.append(("E4", "No peer channels, no pathologies, alignment irrelevant",
                 "Average learning identical (<1%) across scenarios", f"max spread = {100 * spread / g.avg_learning.mean():.2f}%", ok))

    # E5: severe pathologies -> teamwork worse than individual work
    r, g = _means(base.with_(phi_loaf=1.0, c0_conflict=0.6, delta_loaf=0.9, delta_conflict=0.9), n_runs)
    ok = g.loc["random", "avg_learning"] < g.loc["no_teams", "avg_learning"]
    rows.append(("E5", "Severe loafing and conflict", "Random teams learn less than no teams",
                 f"random = {g.loc['random', 'avg_learning']:.2f} vs no teams = {g.loc['no_teams', 'avg_learning']:.2f}", ok))

    # E6: perfect engagement-alignment coupling -> engagement-selected anchors are almost all aligned
    r, g = _means(base.with_(b_align=6.0, b_efficacy=0, b_introv=0, b_stress=0, b_lang=0), n_runs)
    share = g.loc["engagement_anchored", "anchor_aligned_share"]
    ok = share > 0.9
    rows.append(("E6", "Engagement driven by alignment only", "Engagement-selected anchors are aligned (>90%)",
                 f"aligned anchors = {100 * share:.0f}%", ok))

    # E7: no teams and no network ties -> no alignment transitions
    r, g = _means(base.with_(w_net=0.0), n_runs, scenarios=("no_teams",))
    ok = g.negative_conversion.max() == 0 and np.isclose(g.final_aligned.iloc[0], round(base.align_dist[2] * 24))
    rows.append(("E7", "No teams and w_net = 0", "Isolated students never change alignment",
                 f"neg. conversion = {g.negative_conversion.max():.3f}", ok))

    return pd.DataFrame(rows, columns=["ID", "Condition", "Expected behaviour", "Observed", "Pass"])


def pattern_checks(res_main: dict) -> pd.DataFrame:
    S, st = res_main["S"], res_main["students"]
    P1 = team_effect_size(st, "no_teams", "random")
    P2 = S.loc[S.scenario == "random", "gap_sd_units"].mean()
    # P3: initial engagement mix
    e0 = st[st.scenario == "random"].eng0.value_counts(normalize=True).sort_index().to_numpy()
    # P4: monotone identity-distance gradient in learning under random teams
    r = st[st.scenario == "random"].copy()
    r["dist_tercile"] = r.groupby("run").dist.transform(lambda x: pd.qcut(x.rank(method="first"), 3, labels=False))
    grad = r.groupby("dist_tercile").learning.mean().to_numpy()
    rows = [
        ("P1", "Small-group vs individual learning effect (Springer et al. 1999: 0.51 SD)", "0.3-0.7 SD", f"{P1:.2f} SD", 0.3 <= P1 <= 0.7),
        ("P2", "Aligned vs misaligned learning gap: small-to-moderate (Dee 2004; Fairlie et al. 2014)", "0.2-0.8 SD", f"{P2:.2f} SD", 0.2 <= P2 <= 0.8),
        ("P3", "Initial passive/neutral/proactive mix (Table 2)", "30/50/20%",
         "/".join(f"{100 * v:.0f}" for v in e0) + "%", bool(np.allclose(e0, [0.3, 0.5, 0.2], atol=0.03))),
        ("P4", "Learning declines with identity distance (direction of identity-match effects)", "monotone decrease",
         " > ".join(f"{v:.1f}" for v in grad), bool(np.all(np.diff(grad) < 0))),
    ]
    return pd.DataFrame(rows, columns=["ID", "Pattern (source)", "Target", "Simulated", "Pass"])
